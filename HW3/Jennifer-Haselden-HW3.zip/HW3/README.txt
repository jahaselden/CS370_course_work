These files make up the homework 3 assignment for CS370.
