These files make up the homework 2 assignment for CS370.
